import React from 'react'
import Path from './Path'
import PassengerForm from './PassengerForm'
export default function Passenger() {
  return (
    <div className=''>
      <Path/>
      <PassengerForm/>
    </div>
  )
}
